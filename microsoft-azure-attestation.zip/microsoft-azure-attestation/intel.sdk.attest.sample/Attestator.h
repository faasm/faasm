#pragma once

#include "validatequotes/EnclaveInfo.h"

#include <string>
#include <vector>

#include <sgx_report.h>
#include <sgx_ql_lib_common.h>
#include <sgx_dcap_ql_wrapper.h>

using namespace std;

class Attestator
{
    private:
        static EnclaveInfo generateQuote(string enclavePath, vector<uint8_t> enclaveHeldData);
        static bool validateQuote(EnclaveInfo enclaveInfo, string attestDnsName, bool includeDetails);

        //helpers:
        static const char* uint16_to_buffer(char *buffer, uint maxSize, uint16_t n, size_t size);
        static const char* format_hex_buffer (char *buffer, uint maxSize, uint8_t *data, size_t size);
        static bool create_app_enclave_report(const char* enclave_path, sgx_target_info_t qe_target_info, sgx_report_t *app_report, const sgx_report_data_t* p_data);
        static void sha256sum(const uint8_t *data, uint32_t data_size, uint8_t *hash);

    public:
        static bool attestEnclave(string attestDnsName, bool includeDetails, string enclavePath, vector<uint8_t> enclaveHeldData);
};
