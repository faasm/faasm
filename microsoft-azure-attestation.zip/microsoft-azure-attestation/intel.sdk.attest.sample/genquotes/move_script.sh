#!/bin/bash
cp /opt/intel/sgxdcap/QuoteGeneration/build/linux/libsgx_dcap_ql.so* /usr/lib
cp /opt/intel/sgxdcap/QuoteGeneration/build/linux/libsgx_pce_logic.so /usr/lib
cp /opt/intel/sgxdcap/QuoteGeneration/build/linux/libsgx_qe3_logic.so /usr/lib
