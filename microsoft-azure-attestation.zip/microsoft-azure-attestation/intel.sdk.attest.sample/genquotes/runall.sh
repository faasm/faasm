#!/bin/bash
# 
# Script to build, sigg, get quote and export it in JSON format consumable by MAA
#
make all SGX_DEBUG=1
make all SGX_DEBUG=0

