#include "Attestator.h"
#include <iostream>
#include <vector>
using namespace std;

int main()
{
    string attestDnsName = "faasmattprov.eus2.attest.azure.net";
    bool includeDetails = false;
    string enclavePath = "../genquotes/enclave/genquote_enclave.debug.signed";
    vector<uint8_t> enclaveHeldData{0x01, 0x02, 0x03, 0x04, 0x05, 0x06}; //TODO this is where the hash of the loaded function code goes
    bool ret = Attestator::attestEnclave(attestDnsName, includeDetails, enclavePath, enclaveHeldData);
    cout << "Attestator returned: " << ret << endl;
}
