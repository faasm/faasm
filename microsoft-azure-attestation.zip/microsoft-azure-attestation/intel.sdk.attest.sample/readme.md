## Dependencies 
Install the following dependencies.
### apt dependencies
```
sudo apt install cmake rapidjson-dev libcpprest-dev
```

### install manually/add to faasm's external projects
	- https://github.com/Thalhammer/jwt-cpp
	- https://github.com/tplgy/cppcodec

## Installation
First, build the enclave and generate header files.
```
cd genquotes
bash runall.sh
cd ..
```

Then, build the Validator.
```
mkdir build
cd build
cmake ..
make
```

## Running
```
AZDCAP_DEBUG_LOG_LEVEL=debug ./main
```
