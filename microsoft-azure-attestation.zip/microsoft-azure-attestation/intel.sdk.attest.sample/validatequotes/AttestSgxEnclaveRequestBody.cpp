#include "AttestSgxEnclaveRequestBody.h"
#include "EnclaveInfo.h"
#include "helpers/HexHelper.h"

#include <rapidjson/document.h>
#include <rapidjson/stringbuffer.h>
#include <rapidjson/writer.h>


using namespace rapidjson;

AttestSgxEnclaveRequestBody::AttestSgxEnclaveRequestBody(EnclaveInfo* enclaveInfo)
{
    Quote = HexHelper::ConvertHexToBase64Url(enclaveInfo->QuoteHex);
    RuntimeData.Data =  HexHelper::ConvertHexToBase64Url(enclaveInfo->EnclaveHeldDataHex);
    RuntimeData.DataType = "Binary";
}

string AttestSgxEnclaveRequestBody::toJson()
{
    Document d;
    d.SetObject();
    Value outer, inner;

    Document::AllocatorType& allocator = d.GetAllocator();

    //JSON Format: https://docs.microsoft.com/en-us/rest/api/attestation/attestation/attest-sgx-enclave   
    outer.SetObject();
   
    //draftPolicyForAttestation
    outer.AddMember("draftPolicyForAttestation", Value(DraftPolicyForAttestation.c_str(),DraftPolicyForAttestation.size()), allocator);

    //inittimeData
    inner.SetObject();
    inner.AddMember("data", Value(InittimeData.Data.c_str(), InittimeData.Data.size()), allocator);
    inner.AddMember("dataType", Value(InittimeData.DataType.c_str(), InittimeData.DataType.size()), allocator);                   
    outer.AddMember("inittimeData", inner, allocator);

    //quote
    outer.AddMember("quote", Value(Quote.c_str(),Quote.size()), allocator);

    //runTimeData
    inner.SetObject();
    inner.AddMember("data", Value(RuntimeData.Data.c_str(), RuntimeData.Data.size()), allocator);
    inner.AddMember("dataType", Value(RuntimeData.DataType.c_str(), RuntimeData.DataType.size()), allocator);                
    outer.AddMember("runtimeData", inner, allocator);  

     
    d.CopyFrom(outer, allocator);

    StringBuffer buffer;
    Writer<rapidjson::StringBuffer> writer(buffer);
    d.Accept(writer);
    return string( buffer.GetString());
}

