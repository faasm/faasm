#pragma once

#include <string>

using namespace std;

class EnclaveInfo;

class AttestSgxEnclaveRequestBody
{
    class AttestedData
    {
        public:
            string Data;
            string DataType;
    };
    public:
        string Quote;
        AttestedData RuntimeData;
        AttestedData InittimeData;
        string DraftPolicyForAttestation;
        AttestSgxEnclaveRequestBody(EnclaveInfo* enclaveInfo);
        string toJson();
};