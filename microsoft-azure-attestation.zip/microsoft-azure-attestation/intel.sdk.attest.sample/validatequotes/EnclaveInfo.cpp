#include "EnclaveInfo.h"
#include "AttestSgxEnclaveRequestBody.h"
#include "helpers/JoseHelper.h"
#include "helpers/HexHelper.h"

#include <rapidjson/document.h>

#include <fstream>
#include <iostream>
#include <string>
#include <algorithm>
 
using namespace rapidjson;
using namespace std;
 

AttestSgxEnclaveRequestBody* EnclaveInfo::GetMaaBody()
{
    return new AttestSgxEnclaveRequestBody(this);
}

bool EnclaveInfo::CompareToMaaServiceJwtToken(string serviceJwtToken, bool includeDetails)
{
    Document d = JoseHelper::ExtractJosePart(serviceJwtToken, 1);

    bool isDebuggable = (this->Attributes & 2) != 0;
    // In SGX DEBUG flag is equal to 0x0000000000000002ULL 
	// See https://github.com/intel/linux-sgx/blob/master/common/inc/sgx_attributes.h#L39
    bool isd =  d["is-debuggable"].GetBool();
    bool isdpassed = (isd == isDebuggable);
    if (includeDetails)
    {
    	cout << "IsDebuggable match             : " << isdpassed << endl;
        cout << "    We think   : " << isDebuggable << endl;
        cout << "    MAA service: " << isd << endl;
    }

    string mre = d["sgx-mrenclave"].GetString();
    transform(this->MrEnclaveHex.begin(), this->MrEnclaveHex.end(), this->MrEnclaveHex.begin(), ::tolower);
    bool mrepassed = ( this->MrEnclaveHex == mre);
    if (includeDetails)
    {
    	cout << "MRENCLAVE match                : " << mrepassed << endl;
        cout << "    We think   : " << this->MrEnclaveHex << endl;
        cout << "    MAA service: " << mre << endl;
    }

    string mrs = d["sgx-mrsigner"].GetString();
    transform(this->MrSignerHex.begin(), this->MrSignerHex.end(), this->MrSignerHex.begin(), ::tolower);
    bool mrspassed = ( this->MrSignerHex == mrs);
    if (includeDetails)
    {
    	cout << "MRSIGNER match                 : " << mrspassed << endl;
        cout << "    We think   : " << this->MrSignerHex << endl;
        cout << "    MAA service: " << mrs << endl;
    }

    int pid = d["product-id"].GetInt();
    uint64_t expectedPid = *((uint64_t*) HexHelper::ConvertHexToByteArray(this->ProductIdHex).data());
    bool pidpassed = ( expectedPid == pid);
    if (includeDetails)
    {
    	cout << "ProductID match                : " << pidpassed << endl;
        cout << "    We think   : " << expectedPid << endl;
        cout << "    MAA service: " << pid << endl;
    }

    uint svn = d["svn"].GetUint();
    bool svnpassed = (this->SecurityVersion == svn);
    if (includeDetails)
    {
    	cout << "Security Version match         : " << svnpassed << endl;
        cout << "    We think   : " << this->SecurityVersion << endl;
        cout << "    MAA service: " << svn << endl;
    }

    string ehd = d["maa-ehd"].GetString();
    string expectedEhd = HexHelper::ConvertHexToBase64Url(this->EnclaveHeldDataHex);
    bool ehdpassed = (expectedEhd== ehd);
    if (includeDetails)
    {
    	cout << "Enclave Held Data match        : " << ehdpassed << endl;
        cout << "    We think   : " << expectedEhd << endl;
        cout << "    MAA service: " << ehd << endl;
    }

    return (isdpassed &&
            mrepassed &&
            mrspassed &&
            pidpassed &&
            svnpassed &&
            ehdpassed);
}
