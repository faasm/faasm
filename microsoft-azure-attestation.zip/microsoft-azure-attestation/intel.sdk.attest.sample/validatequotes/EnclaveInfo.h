#pragma once

#include <string>
class AttestSgxEnclaveRequestBody;

using namespace std;

class EnclaveInfo
{
    public:
    int Type;
    string MrEnclaveHex;
    string MrSignerHex;
    string ProductIdHex;
    uint SecurityVersion;
    ulong Attributes;
    string QuoteHex;
    string EnclaveHeldDataHex;
    
    static EnclaveInfo CreateFromFile(string filePath);

    AttestSgxEnclaveRequestBody* GetMaaBody();
    bool CompareToMaaServiceJwtToken(string serviceJwtToken, bool includeDetails);
};