#include "MaaService.h"

#include <cpprest/http_client.h>

using namespace web;
using namespace web::http;
using namespace web::http::client;


MaaService::MaaService(string providerDnsName)
{
    this->providerDnsName = providerDnsName;
}

string MaaService::AttestSgxEnclave(AttestSgxEnclaveRequestBody* requestBody)
{
    string uri = "https://" + providerDnsName + ":443/attest/SgxEnclave?api-version=2020-10-01";
    
        http_client client(uri);
        http_request request(methods::POST);
        request.headers().add("Content-Type", "application/json");
        request.set_body(requestBody->toJson());
        pplx::task<http_response> responseTask = client.request(request);
        responseTask.then([=](pplx::task<http_response> task)
        {
            if (task.get().status_code() != status_codes::OK)
            {
                string body = task.get().extract_string().get();
                printf("AttestSgxEnclave: MAA service status code %u. Details: %s\n", task.get().status_code(), body);
            }
        });

        // wait for outstanding task to complete
        try
        {
            responseTask.wait();
        }
        catch (const exception &e)
        {
            printf("Error exception:%s\n", e.what());
        }

    string jwt = responseTask.get().extract_string().get();
    return jwt;
}