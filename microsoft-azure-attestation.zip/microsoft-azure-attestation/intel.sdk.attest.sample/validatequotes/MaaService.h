#pragma once

#include "AttestSgxEnclaveRequestBody.h"

using namespace std;

class MaaService
{
    private:
        string providerDnsName;
        string response;
    public:
        MaaService(string providerDnsName);
        string AttestSgxEnclave(AttestSgxEnclaveRequestBody* requestBody);
};