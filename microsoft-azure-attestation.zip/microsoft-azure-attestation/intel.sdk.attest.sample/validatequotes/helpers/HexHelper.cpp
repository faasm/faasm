#include "HexHelper.h"

#include <stdexcept>
#include <algorithm>
#include <cppcodec/base64_url.hpp>


string HexHelper::ConvertHexToBase64Url(string hexString)
{
    vector<uint8_t> hexBytes = ConvertHexToByteArray(hexString);
    return cppcodec::base64_url::encode(hexBytes);
}

vector<uint8_t> HexHelper::ConvertHexToByteArray(string hexString)
{
    if(hexString.size() % 2 == 1)
    {
        throw runtime_error("ConvertHexToByteArray: Odd number of characters presented!");
    }

    vector<uint8_t> bytes;
    transform(hexString.begin(), hexString.end(), hexString.begin(), ::toupper);
    for (int i = 0; i < hexString.size(); i = i + 2)
    {
        bytes.push_back(CalculateByteValue(hexString[i],hexString[i+1]));
    }
    return bytes;
}

uint8_t HexHelper::CalculateByteValue(char c1, char c2)
{
    return ((CalculateNibbleValue(c1) << 4 ) + CalculateNibbleValue(c2));
}

uint8_t HexHelper::CalculateNibbleValue(char c)
{
    uint8_t value;
    if ((c >= 'A') && c <= 'F')
    {
        value = (c - 'A' + 10);
    }
    else if ((c >= '0') && (c <= '9'))
    {
        value = (c - '0');
    }
    else
    {
        throw runtime_error("CalculateNibbleValue: Character ot ouf bounds!");
    }
    return value;
}
