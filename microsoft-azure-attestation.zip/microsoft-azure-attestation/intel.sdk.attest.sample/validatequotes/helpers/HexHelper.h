#pragma once

#include <string>
#include <vector>

using namespace std;

class HexHelper
{
	public:
		static string ConvertHexToBase64Url(string hexString);
    	static vector<uint8_t> ConvertHexToByteArray(string hexString);

	private:
		static uint8_t CalculateByteValue(char c1, char c2);
		static uint8_t CalculateNibbleValue(char c);
};
