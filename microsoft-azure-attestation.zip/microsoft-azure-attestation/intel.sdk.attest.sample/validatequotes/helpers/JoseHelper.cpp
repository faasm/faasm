#include "JoseHelper.h"

#include <cppcodec/base64_url.hpp>


using namespace rapidjson;

vector<string> JoseHelper::split(const char *str, char c = ' ')
{
    vector<string> result;
    do
    {
        const char *begin = str;
        while(*str != c && *str)
            str++;
        result.push_back(string(begin, str));
    } while (0 != *str++);
    return result;
}


Document JoseHelper::ExtractJosePart(string jwt, int partIndex)
{
    vector<string> joseParts = split(jwt.c_str(), '.');
    
    //padding by adding =
    string base64String = joseParts[partIndex];
    while (base64String.size() % 4 != 0)
    {
        base64String.append("=");
    }
    
    vector<uint8_t> decodedPart = cppcodec::base64_url::decode(base64String);
    const string jsonString(decodedPart.begin(), decodedPart.end());
    Document d;
    d.Parse(jsonString.c_str());
    return d;
}