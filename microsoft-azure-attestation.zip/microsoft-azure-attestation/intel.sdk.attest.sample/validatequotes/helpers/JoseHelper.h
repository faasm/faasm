#pragma once

#include <vector>
#include <string>
#include <rapidjson/document.h>

using namespace std;

class JoseHelper
{
    public:
        static rapidjson::Document ExtractJosePart(string jwt, int partIndex);
    private:
        static vector<string> split(const char* str , char c);

};