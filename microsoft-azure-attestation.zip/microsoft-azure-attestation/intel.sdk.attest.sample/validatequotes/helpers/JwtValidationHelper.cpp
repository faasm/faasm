#include "JwtValidationHelper.h"

#include <string>
#include <iostream>
#include <rapidjson/document.h>

#include <cpprest/http_client.h>

using namespace web;
using namespace web::http;
using namespace web::http::client;
using namespace rapidjson;

jwt::decoded_jwt<jwt::picojson_traits> JwtValidationHelper::ValidateMaaJwt(string attestDnsName, string serviceJwt, bool includeDetails)
{
    string tenantName = attestDnsName;
    string attestUri = "https://" + attestDnsName;

    auto jwksTrustedSigningKeys = RetrieveTrustedSigningKeys(serviceJwt, attestDnsName, tenantName, includeDetails);

    jwt::decoded_jwt<jwt::picojson_traits> validatedToken = ValidateSignedToken(serviceJwt, jwksTrustedSigningKeys, includeDetails);
    ValidateJwtIssuerIsTenant(validatedToken, attestUri, includeDetails);
    //there is no distinct method ValidateSigningCertIssuerMatchesJwtIssuerm because this check is already performed by the jwt-cpp library in ValidateSignedToken

    return validatedToken;
}

void JwtValidationHelper::ValidateJwtIssuerIsTenant(jwt::decoded_jwt<jwt::picojson_traits> validatedToken, string tenantAttestUri, bool includeDetails)
{
    // Verify that the JWT issuer is indeed the tenantAttestUri (tenant specific URI)
    auto jwtTokenIssuerClaim = validatedToken.get_payload_claim("iss");
    if (tenantAttestUri != jwtTokenIssuerClaim.as_string() )
    {
        throw invalid_argument("JWT is not valid (iss claim does not match attest URI");

    }
    if (includeDetails)
    {
    	cout << "JWT issuer claim validation    : True" << endl;
        cout << "JWT issuer claim value         : " + jwtTokenIssuerClaim.as_string() << endl;
    }

}

jwt::decoded_jwt<jwt::picojson_traits> JwtValidationHelper::ValidateSignedToken(string serviceJwt, jwt::jwks<jwt::picojson_traits> jwksTrustedSigningKeys, bool includeDetails)
{
    // Now validate the JWT using the signing keys we just discovered
    auto decoded_jwt = jwt::decode(serviceJwt);
    auto jwk = jwksTrustedSigningKeys.get_jwk(decoded_jwt.get_key_id());
    auto issuer = decoded_jwt.get_issuer();
    auto x5c = jwk.get_x5c_key_value();
    if(!x5c.empty() && !issuer.empty())
    {
        auto verifier = jwt::verify()
            .allow_algorithm(jwt::algorithm::rs256(jwt::helper::convert_base64_der_to_pem(x5c), "", "", ""))
            .with_issuer(issuer)
            .leeway(60UL);

        verifier.verify(decoded_jwt); //throws exception when verification fails
    } else {
        cout << "WARNING: cert or issuer empty!" << endl;
    }

    if(includeDetails)
    {
    	cout << "JWT signature validation       : True" << endl;
    }
    return decoded_jwt;
}

jwt::jwks<jwt::picojson_traits> JwtValidationHelper::RetrieveTrustedSigningKeys(string serviceJwt, string attestDnsName, string tenantName, bool includeDetails)
{
    string expectedCertificateDiscoveryEndpoint = "https://" + attestDnsName + "/certs";

    // Parse attestation service trusted signing key discovery endpoint from JWT header jku field
    auto decoded = jwt::decode(serviceJwt);
    string jsonHeaderString = jwt::decode(serviceJwt).get_header();
    Document d;
    d.Parse(jsonHeaderString.c_str());
    string jkuUri = d["jku"].GetString();

    // Validate that "jku" points to the expected certificate discovery endpoint
    if( expectedCertificateDiscoveryEndpoint != jkuUri )
    {
        throw invalid_argument("JWT JKU header not valid.  Value is " + jkuUri + ".  Expected value is " + expectedCertificateDiscoveryEndpoint);
    }

    if(includeDetails)
    {
    	cout << "JWT JKU location validation    : True" << endl;
        cout << "JWT JKU value                  : " + jkuUri << endl;
    }

    // Retrieve trusted signing keys from the attestation service
    http_client client(jkuUri);
    http_request request(methods::GET);
    request.headers().add("tenantName", tenantName.length() > 24 ? tenantName.substr(0, 24) : tenantName);
    pplx::task<http_response> responseTask = client.request(request);
    responseTask.then([=](pplx::task<http_response> task)
    {
            if (task.get().status_code() != status_codes::OK)
            {
                throw runtime_error("could not reach attesatation service");
            }
    }
    );

    responseTask.wait();

    string jwksValue = responseTask.get().extract_string().get();
    return jwt::parse_jwks(jwksValue);
}

