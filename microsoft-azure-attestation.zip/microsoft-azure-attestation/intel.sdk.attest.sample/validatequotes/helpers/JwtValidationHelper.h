#pragma once

#include <string>
#include <jwt-cpp/jwt.h>


using namespace std;

class JwtValidationHelper
{
    public:
        static jwt::decoded_jwt<jwt::picojson_traits> ValidateMaaJwt(string attestDnsName, string serviceJwt, bool includeDetails);

    private:
        static jwt::decoded_jwt<jwt::picojson_traits> ValidateSignedToken(string serviceJwt, jwt::jwks<jwt::picojson_traits> jwksTrustedSigningKeys, bool includeDetails);
        static jwt::jwks<jwt::picojson_traits> RetrieveTrustedSigningKeys(string serviceJwt, string attestDnsName, string tenantName, bool includeDetails);
        static void ValidateJwtIssuerIsTenant(jwt::decoded_jwt<jwt::picojson_traits> validatedToken, string tenantAttestUri, bool includeDetails);
};