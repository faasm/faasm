#!/bin/bash
# 
# Script to verify all example remote attestation quotes
#
./build/main ../genquotes/out/enclave.info.debug.json              sharedcus.cus.attest.azure.net
./build/main ../genquotes/out/enclave.info.release.json            sharedcus.cus.attest.azure.net
./build/main ../genquotes/out/enclave.info.prodid.json             sharedcus.cus.attest.azure.net
./build/main ../genquotes/out/enclave.info.securityversion.json    sharedcus.cus.attest.azure.net

