﻿namespace validatequotes
{
    public class AttestOpenEnclaveRequestBody
    {
        public string Quote { get; set; }
        public string EnclaveHeldData { get; set; }
    }

}
